cd $(dirname $0)
cd src

python run.py gen && python run.py test ASTGenSuite
