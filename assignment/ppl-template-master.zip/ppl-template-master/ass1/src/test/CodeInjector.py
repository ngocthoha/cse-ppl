from typing import *
import os
import sys
import tokenize
from token import *
import shutil
import abc

LEXER = 1
PARSER = 2


class Template:
    @staticmethod
    def lexer(id: int):
        return [
            "\n",
            "    def test_%d(self):\n" % id,
            "        input = r\"\"\"  \"\"\"\n",
            "        expect = r\"\"\"<EOF>\"\"\"\n",
            "        self.assertTrue(TestLexer.checkLexeme(input, expect, %d))\n" % id
        ]

    @staticmethod
    def parser(id: int):
        return [
            "\n",
            "    def test_%d(self):\n" % id,
            "        input = r\"\"\"\n\n",
            "\"\"\"\n",
            "        expect = r\"\"\"successful\"\"\"\n",
            "        self.assertTrue(TestParser.checkParser(input, expect, %d))\n" % id
        ]


class CodeInjector:

    __caseIds: List[int] = []
    targetPath: str
    target: int
    injector: Any
    templateEngine: Any
    fill: bool = False
    modeOn: bool = False

    def setup(self):
        magicString = os.environ.get('PPL_MAGIC_STRING')
        option = os.environ.get('PPL_OPTION')
        maxCount = os.environ.get('PPL_COUNT')

        # Select target and injector
        if magicString == "l3x3r5u173":
            start = 101
            self.target = LEXER
            self.targetPath = "./test/LexerSuite.py"
            self.injector = self.__stringExpectInjector
            self.templateEngine = Template.lexer
        elif magicString == "p4r53r5u173":
            start = 201
            self.target = PARSER
            self.targetPath = "./test/ParserSuite.py"
            self.injector = self.__stringExpectInjector
            self.templateEngine = Template.parser

        else:
            return

        if option == "f1ll":
            self.fill = True

        lines, tokens = self.__getTarget(self.targetPath)

        defTokenIndexs = [i for i in range(
            len(tokens)) if tokens[i].type == NAME and tokens[i].string == "def"]

        count = 0
        for i in defTokenIndexs:
            j = i
            while not (tokens[j].type == NAME and tokens[j].string == "self"):
                j += 1
            while not (tokens[j].type == NUMBER):
                j += 1
            id = start + count
            self.__replace("test_" + str(id), lines, tokens[i + 1])
            self.__replace(str(id), lines, tokens[j])
            count += 1

        if self.fill:
            try:
                maxCount = int(maxCount)
            except:
                maxCount = 100
            while count < (maxCount if maxCount <= 100 else 100):
                lines.extend(self.templateEngine(start + count))
                count += 1
        self.__caseIds = list(range(start, start + count))

        self.__backup(self.targetPath)
        self.__dump(self.targetPath, lines)
        self.modeOn = True

    def inject(self):
        if not self.modeOn:
            sys.exit(0)

        # Read target file
        lines, tokens = self.__getTarget(self.targetPath)

        # Inject code for each testcase
        for id in self.__caseIds:
            solution = self.__getSolution(id)
            self.injector(id, solution, lines, tokens)

        self.__backup(self.targetPath)
        self.__dump(self.targetPath, lines)

    def __getSolution(self, id: int):
        with open("./test/solutions/" + str(id) + ".txt") as f:
            return f.readline()

    def __getTarget(self, targetPath: str):
        with tokenize.open(targetPath) as f:
            tokens = list(tokenize.generate_tokens(f.readline))
            f.seek(0)
            lines = f.readlines()
        return (lines, tokens)

    def __dump(self, targetPath: str, lines):
        with open(targetPath, "w") as f:
            f.writelines(lines)

    def __backup(self, targetPath: str):
        backupPath = targetPath.replace(".py", ".bak.py")

        if not os.path.isfile(backupPath):
            shutil.copyfile(targetPath, backupPath)

    def __stringExpectInjector(self, id: int, solution: str, lines: List[str], tokens: List[tokenize.TokenInfo]):
        # Find target token
        for i, token in enumerate(tokens):
            if token.type == NUMBER and token.string == str(id):
                targetTokenId = i - 1
                break
        token = tokens[targetTokenId]
        while token.type != STRING:
            targetTokenId = targetTokenId - 1
            token = tokens[targetTokenId]

        # Escape string
        if solution[0] == '"' or solution[-1] in ['\\', '"'] or "#" in solution:
            newSolution = '"' + \
                solution.replace('\\', '\\\\').replace('"', '\\"') + '"'
        else:
            newSolution = 'r"""' + solution + '"""'

        return self.__replace(newSolution, lines, token)

    def __replace(self, value: str, lines: List[str], token: tokenize.TokenInfo):
        startRow, endRow, startCol, endCol = token.start[0] - \
            1, token.end[0] - 1, token.start[1], token.end[1]

        # Same row
        if startRow == endRow:
            line = lines[startRow]
            lines[startRow] = line[0:startCol] + value + line[endCol:]
        return lines
